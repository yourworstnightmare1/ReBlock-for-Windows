README.txt | C:\ReBlock_Projections_Source\main2\README.txt
===========================================================

"main2" and "temp2" is for ReExpand. "main" and "temp" are for ReBlock.