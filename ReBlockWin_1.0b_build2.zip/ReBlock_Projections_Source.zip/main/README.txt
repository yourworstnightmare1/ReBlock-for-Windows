! README.txt - \main\README.txt !

Please don't move the "ReBlock_Projections_Source" folder from the root of the C:\ drive as the developers still don't know how to execute files from the "Program Files" folder without an administrator prompt.
